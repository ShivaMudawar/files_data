# core-java-course-raj

# CoreJavaDemo: This folder contains the examples to explain Core Java concepts

# LibraryMgmtSystem: This folder contains the command line based Library management system source code.
