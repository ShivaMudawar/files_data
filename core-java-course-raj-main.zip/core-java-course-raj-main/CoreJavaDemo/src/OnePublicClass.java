public class OnePublicClass {
	
}

class OMLearning {
	
	
}

class OMProgramming {
	
	
}
