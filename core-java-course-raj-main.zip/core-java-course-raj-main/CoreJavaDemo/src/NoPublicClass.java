class JavaDemo {
	
}

class Learning {
	
	
}

class Programming {
	
	
}
