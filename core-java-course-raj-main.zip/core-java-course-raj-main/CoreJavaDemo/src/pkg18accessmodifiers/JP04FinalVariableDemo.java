package pkg18accessmodifiers;

public class JP04FinalVariableDemo {

	public static void main(String[] args) {

		final double PI_VALUE = 3.14;
		
//		iVal = 10;
	}
}
