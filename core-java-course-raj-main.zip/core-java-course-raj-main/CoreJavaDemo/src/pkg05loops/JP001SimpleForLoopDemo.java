package pkg05loops;

public class JP001SimpleForLoopDemo {

	public static void main(String[] args) {
		
		int count = 0;
		
		for(int i = 10  ; i >= count   ; i = i - 2) {
			System.out.println(i);
		}
	}
}
