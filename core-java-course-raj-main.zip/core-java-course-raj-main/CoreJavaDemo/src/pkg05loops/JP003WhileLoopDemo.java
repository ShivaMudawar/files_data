package pkg05loops;

public class JP003WhileLoopDemo {

	public static void main(String[] args) {
		
		int count = 1;
		while(count <= 10) {
			
			System.out.println(count);
			count = count + 2;
		}
	}
}
