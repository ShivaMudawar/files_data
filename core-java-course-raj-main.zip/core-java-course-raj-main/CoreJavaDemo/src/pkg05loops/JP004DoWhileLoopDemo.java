package pkg05loops;

public class JP004DoWhileLoopDemo {

	public static void main(String[] args) {
		
		int count = 1;
		
		do {

			System.out.println(count);
			count++;
			
		} while(count <= 10);
	}
}
