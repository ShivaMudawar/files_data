package pkg01datatypes;

public class DatatTypes {

	public static void main(String[] args) {
//		boolean b = false;
//		System.out.println(b);
		
//		
//		byte bVal = 127;
//		System.out.println(bVal);
//		
//		
//		short sVal = 234;
//		System.out.println(sVal);
		
//		
//		char sVal = 'B';    // ASCII value
//		System.out.println(sVal);
		
		
//		int iVal = 9;
//		System.out.println(iVal);
		
		// maximum it can allow: 9223372036854775807
//		long lVal = 9223372036854775807L;
//		System.out.println(lVal);
		
		
		float fVal = 12.12121212f;
		System.out.println(fVal);
		
		double dVal = 111111.99999999999;
		System.out.println(dVal);
		
		
		
		
	}
}
