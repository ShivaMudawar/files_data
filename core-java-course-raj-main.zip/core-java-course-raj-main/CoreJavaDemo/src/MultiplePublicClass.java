public class MultiplePublicClass {
	
}

public class MLearning {
	
	
}

class MProgramming {
	
	
}
