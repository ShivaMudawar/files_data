package pkg02operators;

public class AssignmentOperatorsDemo {

	public static void main(String[] args) {
	    int x = 5;
	    x += 3;
	    System.out.println(x);
	    x ^= 3;   // x = x ^ 3   xor
	    System.out.println(x);
	}
}
