package pkg02operators;

public class LogicalOperatorsDemo {

	public static void main(String[] args) {
	    int x = 15;
	    // returns true because 5 is greater than 3 AND 5 is less than 10
	    
	    System.out.println(!(x > 3 || x < 10));
	}
}
