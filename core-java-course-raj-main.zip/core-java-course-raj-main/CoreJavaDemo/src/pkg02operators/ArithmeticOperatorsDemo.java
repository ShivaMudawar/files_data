package pkg02operators;

public class ArithmeticOperatorsDemo {

	public static void main(String[] args) {
	    int x = 5;
	    int y = 3;
//	    System.out.println(x + y);   // prints sum
//	    System.out.println(x * y);   // prints product
//	    System.out.println(x % y);   // prints remainder
//	    --x;   // pre decrement operator
	    System.out.println(x-- + --y);
	    
	}
}
