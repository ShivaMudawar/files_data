package pkg11pack1;

public class A {

	public void display() {
		
		System.out.println("Inside A class pkg11pack1 package.");
	}
}
