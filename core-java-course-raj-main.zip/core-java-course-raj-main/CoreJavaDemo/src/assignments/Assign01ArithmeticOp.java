/*
 * author: Rajendra Prasad G
 * https://github.com/rajenrishi
 * 
 */

package assignments;

//Assignment: 01
//Write a Java program to define two numbers and perform arithmetic operations and print the output. 

public class Assign01ArithmeticOp {

	public static void main(String[] args) {
	    int x = 010;
	    int y = 3;
	    System.out.println("Sum: " + (x + y));
	    System.out.println("Difference: " + (x - y));
	    System.out.println("Product: " + (x * y));
	    System.out.println("Modulus: " + (x % y));
	}
}
