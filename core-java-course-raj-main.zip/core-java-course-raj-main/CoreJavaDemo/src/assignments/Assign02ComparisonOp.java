/*
 * author: Rajendra Prasad G
 * https://github.com/rajenrishi
 * 
 */

package assignments;

//Assignment: 02
//Write a Java program to define two numbers and perform comparison operations and print the output.

public class Assign02ComparisonOp {

	public static void main(String[] args) {
	    int x = 5;
	    int y = 3;
	    System.out.println("Equal To: " + (x == y));
	    System.out.println("Less Than: " + (x < y));
	    System.out.println("Greater Than: " + (x > y));
	}
}
