package pkg03conditionalstmts;

public class IfElseIfStatementsDemo {

	public static void main(String[] args) {
		
		int num = 3;
		if (num > 5) {
			
			System.out.println("If block");
			
		} else if (num == 2) {
			
			System.out.println("else if block");
		
		} else {
			
			System.out.println("else block");
		}
	}
}
