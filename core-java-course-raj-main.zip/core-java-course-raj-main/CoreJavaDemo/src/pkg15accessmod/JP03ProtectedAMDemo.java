package pkg15accessmod;

class ProDiffClassA {
	
	protected int data = 30;
	
	protected void display() {
		
		System.out.println("In protected method Class ProDiffClassA: " + data);
	}
}