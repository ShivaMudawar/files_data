package pkg15accessmod;

class DefDiffClassA {   // Default modifier
	
	int data = 30;
	
	void display() {
		
		System.out.println("In default method Class DefDiffClassA: " + data);
	}
}