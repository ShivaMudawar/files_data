package pkg06arrays;

public class ArraysDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
