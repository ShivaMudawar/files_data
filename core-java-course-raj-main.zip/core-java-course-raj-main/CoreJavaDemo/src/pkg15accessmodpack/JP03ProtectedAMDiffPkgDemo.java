package pkg15accessmodpack;

public class JP03ProtectedAMDiffPkgDemo {
	
	protected int data = 30;
	
	protected void display() {
		
		System.out.println("In protected method Class JP03ProtectedAMDiffPkgDemo: " + data);
	}
}