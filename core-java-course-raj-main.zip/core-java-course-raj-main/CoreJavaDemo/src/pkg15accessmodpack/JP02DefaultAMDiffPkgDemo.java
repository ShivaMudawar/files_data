package pkg15accessmodpack;

class DefDiffPkgA {
	
	int data = 30;
	
	void display() {
		
		System.out.println("In default method Class DefDiffPkgA: " + data);
	}
}