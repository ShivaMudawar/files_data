package pkg11pkgsdemo;

import pkg11pack1.*;

public class BImportAllClasses {

	public static void main(String[] args) {

		A aObj = new A();
		aObj.display();
	}
}
