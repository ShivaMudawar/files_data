public class FJavaDemo {
	
}

class FLearning {
	
	
}

class FProgramming {
	
	
}
