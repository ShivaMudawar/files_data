package pkg10thiskeyword;

public class JPThisKeywordCallConstDemo {
	int length;
	int breadth;
	
	JPThisKeywordCallConstDemo(int len, int bre) {
		
		this.length = len;
		this.breadth = bre;
	}

	public static void main(String[] args) {
		
		JPThisKeywordCallConstDemo obj = new JPThisKeywordCallConstDemo(10, 5);
		
	}
}
